#pragma once

#include <windows.h>

HANDLE transacted_hollowing(wchar_t* tmpFile, wchar_t* programPath, wchar_t* cmdLine, BYTE* payladBuf, DWORD payloadSize, wchar_t* startDir);