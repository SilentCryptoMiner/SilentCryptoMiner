#pragma once

#include <windows.h>

bool has_gpu();

PROCESS_INFORMATION create_new_process_internal(LPWSTR cmdLine, LPWSTR startDir, DWORD creationFlags);

void run_program(bool wait, wchar_t* cmdLine, ...);

bool check_mutex(LPCWSTR mutex);