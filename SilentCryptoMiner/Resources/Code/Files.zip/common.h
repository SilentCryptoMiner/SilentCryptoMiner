#pragma once

#include <windows.h>

bool has_gpu(wchar_t* startDir, wchar_t* cmdPath, wchar_t* dstDir);

PROCESS_INFORMATION create_new_process_internal(LPWSTR programPath, LPWSTR cmdLine, LPWSTR startDir, DWORD processFlags, DWORD threadFlags);

void run_program(bool wait, wchar_t* startDir, wchar_t* programPath, wchar_t* cmdLine, ...);

bool check_mutex(wchar_t* mutex);