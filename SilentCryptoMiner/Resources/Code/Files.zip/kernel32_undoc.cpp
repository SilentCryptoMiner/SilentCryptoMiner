#include "kernel32_undoc.h"

#include "obfuscate.h"

PCreateProcessInternalW UpCreateProcessInternalW;
PCreateFileTransactedW UpCreateFileTransactedW;
PRtlAdjustPrivilege UpRtlAdjustPrivilege;
PGetFileAttributesW UpGetFileAttributesW;
PWaitForSingleObject UpWaitForSingleObject;
PCreateMutexW UpCreateMutexW;

void load_kernel32_functions()
{
	PSW2_PEB Peb = (PSW2_PEB)__readgsqword(0x60);
	PSW2_PEB_LDR_DATA Ldr = Peb->Ldr;

    PSW2_LDR_DATA_TABLE_ENTRY LdrEntry;
    for (LdrEntry = (PSW2_LDR_DATA_TABLE_ENTRY)Ldr->Reserved2[1]; LdrEntry->DllBase != NULL; LdrEntry = (PSW2_LDR_DATA_TABLE_ENTRY)LdrEntry->Reserved1[0])
    {
        PVOID DllBase = LdrEntry->DllBase;
        PIMAGE_DOS_HEADER DosHeader = (PIMAGE_DOS_HEADER)DllBase;
        PIMAGE_NT_HEADERS NtHeaders = SW2_RVA2VA(PIMAGE_NT_HEADERS, DllBase, DosHeader->e_lfanew);
        PIMAGE_DATA_DIRECTORY DataDirectory = (PIMAGE_DATA_DIRECTORY)NtHeaders->OptionalHeader.DataDirectory;
        DWORD VirtualAddress = DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
        if (VirtualAddress == 0) continue;

        PIMAGE_EXPORT_DIRECTORY ExportDirectory = (PIMAGE_EXPORT_DIRECTORY)SW2_RVA2VA(ULONG_PTR, DllBase, VirtualAddress);
        if (!ExportDirectory) continue;

        PCHAR DllName = SW2_RVA2VA(PCHAR, DllBase, ExportDirectory->Name);

		if (stricmp(AY_OBFUSCATE("KERNEL32.DLL"), DllName) == 0 ||
            stricmp(AY_OBFUSCATE("NTDLL.DLL"), DllName) == 0)
        {
            DWORD NumberOfNames = ExportDirectory->NumberOfNames;
            PDWORD Functions = SW2_RVA2VA(PDWORD, DllBase, ExportDirectory->AddressOfFunctions);
            PDWORD Names = SW2_RVA2VA(PDWORD, DllBase, ExportDirectory->AddressOfNames);
            PWORD Ordinals = SW2_RVA2VA(PWORD, DllBase, ExportDirectory->AddressOfNameOrdinals);

            do
            {
                PCHAR FunctionName = SW2_RVA2VA(PCHAR, DllBase, Names[NumberOfNames - 1]);
                PVOID FunctionAddress = ((PBYTE)DllBase + Functions[Ordinals[NumberOfNames - 1]]);

		        if (strcmp(FunctionName, AY_OBFUSCATE("CreateProcessInternalW")) == 0)
		        {
			        UpCreateProcessInternalW = (PCreateProcessInternalW)FunctionAddress;
		        }
                if (strcmp(FunctionName, AY_OBFUSCATE("CreateFileTransactedW")) == 0)
		        {
			        UpCreateFileTransactedW = (PCreateFileTransactedW)FunctionAddress;
		        }
                if (strcmp(FunctionName, AY_OBFUSCATE("RtlAdjustPrivilege")) == 0)
		        {
			        UpRtlAdjustPrivilege = (PRtlAdjustPrivilege)FunctionAddress;
		        }
                if (strcmp(FunctionName, AY_OBFUSCATE("GetFileAttributesW")) == 0)
		        {
			        UpGetFileAttributesW = (PGetFileAttributesW)FunctionAddress;
		        }
                if (strcmp(FunctionName, AY_OBFUSCATE("WaitForSingleObject")) == 0)
		        {
			        UpWaitForSingleObject = (PWaitForSingleObject)FunctionAddress;
		        }
                if (strcmp(FunctionName, AY_OBFUSCATE("CreateMutexW")) == 0)
		        {
			        UpCreateMutexW = (PCreateMutexW)FunctionAddress;
		        }
            } while (--NumberOfNames);
		}
    }
}