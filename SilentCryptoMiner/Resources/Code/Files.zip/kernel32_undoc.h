#pragma once

#include "ntddk.h"

typedef BOOL(WINAPI *PCreateProcessInternalW)(HANDLE, LPCWSTR, LPWSTR, LPSECURITY_ATTRIBUTES, LPSECURITY_ATTRIBUTES, BOOL, DWORD, LPVOID, LPCWSTR, LPSTARTUPINFOW, LPPROCESS_INFORMATION, PHANDLE);

typedef HANDLE(WINAPI *PCreateFileTransactedW)(LPCWSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE, HANDLE, PUSHORT, PVOID);

typedef NTSTATUS(WINAPI *PRtlAdjustPrivilege)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);

typedef DWORD(WINAPI *PGetFileAttributesW)(LPCWSTR);

typedef DWORD(WINAPI *PWaitForSingleObject)(HANDLE, DWORD);

typedef HANDLE(WINAPI *PCreateMutexW)(LPSECURITY_ATTRIBUTES, BOOL, LPCWSTR);


extern PCreateProcessInternalW UpCreateProcessInternalW;
extern PCreateFileTransactedW UpCreateFileTransactedW;
extern PRtlAdjustPrivilege UpRtlAdjustPrivilege;
extern PGetFileAttributesW UpGetFileAttributesW;
extern PWaitForSingleObject UpWaitForSingleObject;
extern PCreateMutexW UpCreateMutexW;

void load_kernel32_functions();