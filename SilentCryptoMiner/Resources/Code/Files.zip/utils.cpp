#include "utils.h"

#include "ntddk.h"
#include <string>

void combine_path(wchar_t* src, wchar_t* basepath, wchar_t* extpath) {
    wcscpy(src, basepath);
    wcscat(src, extpath);
}

void get_directory(wchar_t* src, wchar_t* dst) {
    wcscpy(dst, src);
    size_t len = wcslen(dst);
    for (size_t i = len - 2; i >= 0; i--) {
        if (dst[i] == '\\' || dst[i] == '/') {
            dst[i] = '\0';
            break;
        }
    }
}

HANDLE open_file(wchar_t* filePath, bool readOnly) {
    std::wstring nt_path = L"\\??\\" + std::wstring(filePath);

    UNICODE_STRING file_name;
    INIT_UNICODE_STRING(file_name, nt_path);

    OBJECT_ATTRIBUTES attr = { 0 };
    InitializeObjectAttributes(&attr, &file_name, OBJ_CASE_INSENSITIVE, NULL, NULL);

    IO_STATUS_BLOCK status_block = { 0 };
    HANDLE file;
    NTSTATUS stat;
    if (readOnly) {
        stat = UtOpenFile(&file,
            SYNCHRONIZE | GENERIC_READ,
            &attr,
            &status_block,
            FILE_SHARE_READ,
            FILE_SYNCHRONOUS_IO_NONALERT
        );
    }else{
        stat = UtOpenFile(&file,
            DELETE | SYNCHRONIZE | GENERIC_READ | GENERIC_WRITE,
            &attr,
            &status_block,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            FILE_SUPERSEDE | FILE_SYNCHRONOUS_IO_NONALERT
        );
    }
    if (!NT_SUCCESS(stat)) {
        return INVALID_HANDLE_VALUE;
    }

    return file;
}

HANDLE create_directory(wchar_t* dirPath) {
    std::wstring nt_path = L"\\??\\" + std::wstring(dirPath);

    UNICODE_STRING dir_name;
    INIT_UNICODE_STRING(dir_name, nt_path);

    OBJECT_ATTRIBUTES attr = { 0 };
    InitializeObjectAttributes(&attr, &dir_name, OBJ_CASE_INSENSITIVE, NULL, NULL);

    IO_STATUS_BLOCK status_block = { 0 };
    HANDLE file;
    if (!NT_SUCCESS(UtCreateFile(&file,
        FILE_GENERIC_WRITE,
        &attr,
        &status_block,
        NULL,
        FILE_ATTRIBUTE_NORMAL,
        0,
        FILE_OPEN_IF,
        FILE_DIRECTORY_FILE,
        NULL,
        0
    ))) {
        return INVALID_HANDLE_VALUE;
    }
    return file;
}

void create_recursive_directory(wchar_t* dirPath) {
    size_t len = wcslen(dirPath);
    for (size_t i = 0; i <= len; i++) {
        if (dirPath[i] == '\\' || dirPath[i] == '/') {
            wchar_t partPath[MAX_PATH] = { 0 };
            wcscpy(partPath, dirPath);
            partPath[i] = '\0';
            create_directory(partPath);
        }
    }
}

HANDLE create_file(wchar_t* filePath) {
    std::wstring nt_path = L"\\??\\" + std::wstring(filePath);

    UNICODE_STRING file_name;
    INIT_UNICODE_STRING(file_name, nt_path);

    OBJECT_ATTRIBUTES attr = { 0 };
    InitializeObjectAttributes(&attr, &file_name, OBJ_CASE_INSENSITIVE, NULL, NULL);

    IO_STATUS_BLOCK status_block = { 0 };
    HANDLE file;
    if (!NT_SUCCESS(UtCreateFile(&file,
        DELETE | SYNCHRONIZE | GENERIC_READ | GENERIC_WRITE,
        &attr,
        &status_block,
        NULL,
        FILE_ATTRIBUTE_NORMAL,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        FILE_SUPERSEDE,
        FILE_SYNCHRONOUS_IO_NONALERT,
        NULL,
        0
    ))) {
        return INVALID_HANDLE_VALUE;
    }
    return file;
}

PVOID read_file(wchar_t* filePath, ULONG* outFileSize) {
    HANDLE hFile = open_file(filePath, true);
    if (hFile == INVALID_HANDLE_VALUE) {
        return { 0 };
    }

    IO_STATUS_BLOCK status_block = { 0 };
    LARGE_INTEGER ByteOffset = { 0 };

    *outFileSize = GetFileSize(hFile, NULL);
    PVOID fileData = HeapAlloc(GetProcessHeap(), 0, *outFileSize);
    NTSTATUS status = UtReadFile(
        hFile,
        NULL,
        NULL,
        NULL,
        &status_block,
        fileData,
        *outFileSize,
        NULL,
        NULL
    );

    UtClose(hFile);
    if (!NT_SUCCESS(status)) {
        return { 0 };
    }

    return fileData;
}

bool write_file(wchar_t* filePath, PVOID payladBuf, ULONG payloadSize) {
    create_recursive_directory(filePath);
    HANDLE hFile = create_file(filePath);
    if (hFile == INVALID_HANDLE_VALUE) {
        return false;
    }

    IO_STATUS_BLOCK status_block = { 0 };
    NTSTATUS status = UtWriteFile(
        hFile,
        NULL,
        NULL,
        NULL,
        &status_block,
        payladBuf,
        payloadSize,
        NULL,
        NULL
    );

    UtClose(hFile);
    if (!NT_SUCCESS(status)) {
        return false;
    }
    return true;
}