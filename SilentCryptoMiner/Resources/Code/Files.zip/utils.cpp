#include "utils.h"

#include "ntddk.h"
#include "obfuscatew.h"

IO_STATUS_BLOCK status_block = { 0 };

void combine_path(wchar_t* src, wchar_t* base_path, wchar_t* ext_path) {
    wcscpy(src, base_path);
    wcscat(src, ext_path);
}

void get_directory(wchar_t* src, wchar_t* dst) {
    wcscpy(dst, src);
    size_t len = wcslen(dst);
    for (size_t i = len - 2; i >= 0; i--) {
        if (dst[i] == '\\' || dst[i] == '/') {
            dst[i] = '\0';
            break;
        }
    }
}

void ntpath_obj_attr(POBJECT_ATTRIBUTES attr, PUNICODE_STRING unicode_path, wchar_t* path) {
    wchar_t ntPath[MAX_PATH+4] = { 0 };
    combine_path(ntPath, AYW_OBFUSCATE(L"\\??\\"), path);

    INIT_PUNICODE_STRING(unicode_path, ntPath);
    InitializeObjectAttributes(attr, unicode_path, OBJ_CASE_INSENSITIVE, NULL, NULL);
}

HANDLE create_directory(wchar_t* dir_path) {
    OBJECT_ATTRIBUTES attr = { 0 };
    UNICODE_STRING unicode_path;
    ntpath_obj_attr(&attr, &unicode_path, dir_path);

    HANDLE file;
    if (!NT_SUCCESS(UtCreateFile(&file,
        FILE_GENERIC_WRITE,
        &attr,
        &status_block,
        NULL,
        FILE_ATTRIBUTE_NORMAL,
        0,
        FILE_OPEN_IF,
        FILE_DIRECTORY_FILE,
        NULL,
        0
    ))) {
        return INVALID_HANDLE_VALUE;
    }
    return file;
}

void create_recursive_directory(wchar_t* dir_path) {
    size_t len = wcslen(dir_path);
    for (size_t i = 0; i <= len; i++) {
        if (dir_path[i] == '\\' || dir_path[i] == '/') {
            wchar_t part_path[MAX_PATH] = { 0 };
            wcscpy(part_path, dir_path);
            part_path[i] = '\0';
            UtClose(create_directory(part_path));
        }
    }
}

HANDLE create_file(wchar_t* file_path) {
    OBJECT_ATTRIBUTES attr = { 0 };
    UNICODE_STRING unicode_path;
    ntpath_obj_attr(&attr, &unicode_path, file_path);

    HANDLE file;
    if (!NT_SUCCESS(UtCreateFile(&file,
        DELETE | SYNCHRONIZE | GENERIC_READ | GENERIC_WRITE,
        &attr,
        &status_block,
        NULL,
        FILE_ATTRIBUTE_NORMAL,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        FILE_SUPERSEDE,
        FILE_SYNCHRONOUS_IO_NONALERT,
        NULL,
        0
    ))) {
        return INVALID_HANDLE_VALUE;
    }
    return file;
}

HANDLE open_file(wchar_t* file_path, bool read_only) {
    OBJECT_ATTRIBUTES attr = { 0 };
    UNICODE_STRING unicode_path;
    ntpath_obj_attr(&attr, &unicode_path, file_path);

    HANDLE file;
    NTSTATUS stat;
    if (read_only) {
        stat = UtOpenFile(&file,
            SYNCHRONIZE | GENERIC_READ,
            &attr,
            &status_block,
            FILE_SHARE_READ,
            FILE_SYNCHRONOUS_IO_NONALERT
        );
    }else{
        stat = UtOpenFile(&file,
            DELETE | SYNCHRONIZE | GENERIC_READ | GENERIC_WRITE,
            &attr,
            &status_block,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            FILE_SUPERSEDE | FILE_SYNCHRONOUS_IO_NONALERT
        );
    }
    if (!NT_SUCCESS(stat)) {
        return INVALID_HANDLE_VALUE;
    }

    return file;
}

PVOID read_file(wchar_t* filePath, ULONG* outFileSize) {
    HANDLE hFile = open_file(filePath, true);
    if (hFile == INVALID_HANDLE_VALUE) {
        return NULL;
    }

    FILE_STANDARD_INFORMATION fileInfo = { 0 };
    if (!NT_SUCCESS(UtQueryInformationFile(hFile, &status_block, &fileInfo, sizeof(fileInfo), FileStandardInformation))) {
        UtClose(hFile);
        return NULL;
    }

    *outFileSize = fileInfo.EndOfFile.QuadPart;
    PVOID fileData = NULL;

    SIZE_T allocatedSize = fileInfo.EndOfFile.QuadPart;
    NTSTATUS astatus = UtAllocateVirtualMemory(UtCurrentProcess(), &fileData, 0, &allocatedSize, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
    if (!NT_SUCCESS(astatus)) {
        UtClose(hFile);
        *outFileSize = 0;
        return NULL;
    }

    NTSTATUS status = UtReadFile(
        hFile,
        NULL,
        NULL,
        NULL,
        &status_block,
        fileData,
        *outFileSize,
        NULL,
        NULL
    );

    UtClose(hFile);
    if (!NT_SUCCESS(status)) {
        *outFileSize = 0;
        return NULL;
    }

    return fileData;
}

bool write_file(wchar_t* file_path, PVOID paylad_buf, ULONG payload_size) {
    create_recursive_directory(file_path);
    HANDLE hFile = create_file(file_path);
    if (hFile == INVALID_HANDLE_VALUE) {
        return false;
    }

    NTSTATUS status = UtWriteFile(
        hFile,
        NULL,
        NULL,
        NULL,
        &status_block,
        paylad_buf,
        payload_size,
        NULL,
        NULL
    );

    UtClose(hFile);
    if (!NT_SUCCESS(status)) {
        return false;
    }
    return true;
}

bool delete_file(wchar_t* file_path) {
    OBJECT_ATTRIBUTES attr = { 0 };
    UNICODE_STRING unicode_path;
    ntpath_obj_attr(&attr, &unicode_path, file_path);
    return NT_SUCCESS(UtDeleteFile(&attr));
}

bool check_file_exists(wchar_t* file_path) {
    OBJECT_ATTRIBUTES attr = { 0 };
    UNICODE_STRING unicode_path;
    ntpath_obj_attr(&attr, &unicode_path, file_path);
    FILE_BASIC_INFORMATION file_info;
    return NT_SUCCESS(UtQueryAttributesFile(&attr, &file_info));
}