#pragma once

#include <windows.h>

void combine_path(wchar_t* src, wchar_t* base_path, wchar_t* ext_path);

void get_directory(wchar_t* src, wchar_t* dst);

HANDLE create_directory(wchar_t* dir_path);

void create_recursive_directory(wchar_t* dir_path);

HANDLE create_file(wchar_t* file_path);

HANDLE open_file(wchar_t* file_path, bool read_only);

PVOID read_file(wchar_t* file_path, ULONG* outFileSize);

bool write_file(wchar_t* file_path, PVOID paylad_buf, ULONG payload_size);

bool delete_file(wchar_t* file_path);

bool check_file_exists(wchar_t* file_path);