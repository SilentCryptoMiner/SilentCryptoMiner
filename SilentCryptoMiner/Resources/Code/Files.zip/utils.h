#pragma once

#include <windows.h>

void combine_path(wchar_t* src, wchar_t* basepath, wchar_t* extpath);

void get_directory(wchar_t* src, wchar_t* dst);

HANDLE create_directory(wchar_t* dirPath);

void create_recursive_directory(wchar_t* dirPath);

HANDLE open_file(wchar_t* filePath, bool readOnly);

HANDLE create_file(wchar_t* filePath);

PVOID read_file(wchar_t* filePath, ULONG* outFileSize);

bool write_file(wchar_t* filePath, PVOID payladBuf, ULONG payloadSize);